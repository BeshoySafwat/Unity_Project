using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaceMovement : MonoBehaviour
{
    public float Speed = 0.8f;
    public float Range = 3;
    float StartingY;
    int dir = 1;
    void Start()
    {
        StartingY= transform.position.y;
    }

    // FixedUpdate is called once per frame And Recommended For Animation and Move Something
    //Update is called once per frame And  Recommended For input 
    void FixedUpdate()
    {
        transform.Translate(Vector2.up * Speed * Time.deltaTime * dir);
        if (transform.position.y < StartingY || transform.position.y > StartingY + Range)
            dir *= -1;
    }
}
