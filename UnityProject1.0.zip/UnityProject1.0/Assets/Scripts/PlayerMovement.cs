using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    PlayerControls controls;
    float dir = 0;
    public float speed = 5;
    public float JumpForce=5;
    int numberOfJumps=0;
    bool isGrounded =true;
    public Transform groundCheck;
    public LayerMask groundLayer;
    public Rigidbody2D PlayerRigidBody;
    public Animator animator;
    public bool isFacingRight = true;
    private void Awake()
    {
        controls=new PlayerControls();
        controls.Enable();

        controls.Land.Move.performed += ctx =>
        {
            dir = ctx.ReadValue<float>();
        };
        controls.Land.Jump.performed += ctx =>
        {
            Jump();
        };
    }
    void Flip()
    {
        isFacingRight = !isFacingRight;
        transform.localScale = new Vector2(transform.localScale.x * -1, transform.localScale.y);
    }
    // Update is called once per frame
    void FixedUpdate()
    {

        PlayerRigidBody.velocity = new Vector2(dir * speed * Time.fixedDeltaTime, PlayerRigidBody.velocity.y);
        animator.SetFloat("Speed", Mathf.Abs(dir));

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, 0.1f, groundLayer);
        animator.SetBool("ISGrounded", isGrounded);

        if (isFacingRight && dir < 0 || !isFacingRight && dir > 0)
            Flip();
        //if(Input.GetKeyDown(KeyCode.RightArrow) == true) {
        //    PlayerRigidBody.velocity = Vector2.right * speed;
        //}
        //else if(Input.GetKeyDown(KeyCode.LeftArrow) == true)
        //{
        //    PlayerRigidBody.velocity = Vector2.left * speed;
        //}
    }
    public void Jump()
    {
        if (isGrounded)
        {
            numberOfJumps = 0;
            PlayerRigidBody.velocity = new Vector2(PlayerRigidBody.velocity.x, JumpForce);
            numberOfJumps++;
           
        }
        else
        {
            if (numberOfJumps == 1)
            {
                PlayerRigidBody.velocity = new Vector2(PlayerRigidBody.velocity.x, JumpForce);
                numberOfJumps++;
            }
        }
    }

}
